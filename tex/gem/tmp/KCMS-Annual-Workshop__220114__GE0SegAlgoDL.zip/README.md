#
https://indico.cern.ch/event/1109127/contributions/4673678/
- 14 Jan 2022, 20:00
- 10m
- Convener: Hwi Dong Yoo (Yonsei University (KR))

##
https://pytorch.org/assets/brand-guidelines/PyTorch-Brand-Guidelines.pdf 